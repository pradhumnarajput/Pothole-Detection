
Pothole - v1 raw
==============================

This dataset was exported via roboflow.ai on November 1, 2020 at 11:13 PM GMT

It includes 665 images.
Potholes are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


